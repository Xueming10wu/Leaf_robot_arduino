#include "ManipulatorProtocol.h"

ManipulatorProtocol::ManipulatorProtocol()
{
    udpHandle = new UDP();
}

ManipulatorProtocol::~ManipulatorProtocol()
{
    delete []msg.value;
    msg.value = NULL;
    delete []manipulator.stream;
    manipulator.stream = NULL;
}

/*
void ManipulatorProtocol::setSerialPort( string serialport_name, int baudrate )
{
    udpHandle->setSerialPort( serialport_name, baudrate );
}
*/

void ManipulatorProtocol::manipulatorInit(int degrees)
{
    manipulator.degrees = degrees;
    StepMotor stepmotor = { 1.8, 32, 0, 0, 0 };
    manipulator.stepMotorList = new StepMotor[degrees];
    for (size_t i = 0; i < manipulator.degrees; i ++)
    {
        //manipulator.stepMotorList.push_back(stepmotor);
        manipulator.stepMotorList[i] = stepmotor;
    }
    manipulator.stream = new uint8_t[manipulator.degrees*3*3];
    udpHandle->setMessageValueSize(msg, manipulator.degrees*3*3);

    //下层设置
    msg.start = (uint8_t)'$';
    //msg.value = manipulator.stream;   //较为危险，所以选择memcpy
    msg.end = (uint8_t)'!';
}

int ManipulatorProtocol::read()
{
    msg.start = (uint8_t)'$';
    msg.end = (uint8_t)'!';
    int len = udpHandle->read(msg);
    if (len == 0)
    {
        memcpy(manipulator.stream, msg.value, msg.valueSize);
        for (size_t i = 0; i < manipulator.degrees; i ++)
        {
            manipulator.stepMotorList[i].position = ((manipulator.stream[i*3*3+1] << 8 ) | manipulator.stream[i*3*3+2]) & 0xffff;
            manipulator.stepMotorList[i].velocity = ((manipulator.stream[i*3*3+4] << 8 ) | manipulator.stream[i*3*3+5]) & 0xffff;
            manipulator.stepMotorList[i].effort = ((manipulator.stream[i*3*3+7] << 8 ) | manipulator.stream[i*3*3+8]) & 0xffff;
            
            manipulator.stream[i*3*3+0] == 0xf0 ? manipulator.stepMotorList[i].position *= -1 : manipulator.stepMotorList[i].position *= 1;
            manipulator.stream[i*3*3+3] == 0xf0 ? manipulator.stepMotorList[i].velocity *= -1 : manipulator.stepMotorList[i].velocity *= 1;
            manipulator.stream[i*3*3+6] == 0xf0 ? manipulator.stepMotorList[i].effort *= -1 : manipulator.stepMotorList[i].effort *= 1;
        }
    }
    return len;
}


int ManipulatorProtocol::write()
{
    msg.start = (uint8_t)'$';
    msg.end = (uint8_t)'!';


    for (size_t i = 0; i < manipulator.degrees; i ++)
    {
        manipulator.stream[i*3*3+1] = (abs(manipulator.stepMotorList[i].position) >> 8) & 0xff;
        manipulator.stream[i*3*3+2] = abs(manipulator.stepMotorList[i].position) & 0xff;
        manipulator.stream[i*3*3+4] = (abs(manipulator.stepMotorList[i].velocity) >> 8) & 0xff;
        manipulator.stream[i*3*3+5] = abs(manipulator.stepMotorList[i].velocity) & 0xff;
        manipulator.stream[i*3*3+7] = (abs(manipulator.stepMotorList[i].effort) >> 8) & 0xff;
        manipulator.stream[i*3*3+8] = abs(manipulator.stepMotorList[i].effort) & 0xff;

        manipulator.stepMotorList[i].position < 0 ? manipulator.stream[i*3*3+0] = 0xf0 : manipulator.stream[i*3*3+0] = 0x0f;
        manipulator.stepMotorList[i].velocity < 0 ? manipulator.stream[i*3*3+3] = 0xf0 : manipulator.stream[i*3*3+3] = 0x0f;
        manipulator.stepMotorList[i].effort < 0 ? manipulator.stream[i*3*3+6] = 0xf0 : manipulator.stream[i*3*3+6] = 0x0f;
    }
    memcpy(msg.value, manipulator.stream, msg.valueSize);
    return udpHandle->write(msg);
}